import java.util.ArrayList;
import java.util.Arrays;
public class Manager extends CommonAttributes {

    private String firstName;
    private String lastName;
    private String fullName;

    public Manager(String firstName, String lastName) {
        super(firstName,lastName);
    }

}
