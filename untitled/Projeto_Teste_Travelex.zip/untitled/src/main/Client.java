public class Client  extends CommonAttributes{

    public Client(String firstName, String lastName) {
        super(firstName,lastName);
    }
}
