public class Robot  extends CommonAttributes{
    public Robot(String firstName, String lastName) {
        super(firstName,lastName);
    }
}
